import mongoose from "mongoose";
import bcrypt from "bcrypt";

const userSchema = new mongoose.Schema({
    userName :{
        type :String,
        required : true
    },
    email:{
        type :String,
        required : true
    },
    phoneNumber:{
        type :Number,
    },
    profileImage:{
        data: Buffer, 
        contentType: String 
    },
    password:{
        type :String,
    }
}) //type: 'buffer'
userSchema.pre('save',async function (next){
    const salt = await bcrypt.genSalt();
    this.password = await bcrypt.hash(this.password, salt);
    next();
})
const userModal = mongoose.model('user' , userSchema)
export default userModal