import express from 'express';
import connectDB from './config/db.js';
import  { createUser, getUser}   from './Controller/controller.js'
import  updateUser   from './Controller/controller.js'

const app = express();

const port = '4200';

connectDB().then((res) =>{
    console.log(res);
});





app.use(express.json());
app.use(express.urlencoded({extended: true}));

app.get('/user/get/:email', getUser)
app.post('/user/create', createUser)
app.post('/user/update/:email', updateUser)


app.listen(port ,  (req,res)=>{
    console.log(`Server started at http://localhost:${port}`);
})

