import userModal from "../Modal/registration.js"

export  async function getUser(req, res) {
    try {
        const emailID = req.params.email;
        if (!emailID) {
            return res.status(400).json({ errorMessage: "Please enter emailID" });
        }
        const result = await userModal.find({email:emailID});
        return res.json({Message:"Profile Detail Find Successfully",
        data:result});
    } catch (error) {
        console.log(error);
        res.send('Something went wrong');
    }
}
export async function createUser(req, res) {
    try {
        const { userName, email, phoneNumber, profileImage, password } = req.body;
        if (!userName || !email || !password) {
            return res.status(400).json({ errorMessage: "Please enter all required fields" });
        }
        const emailID = await userModal.find({ email: email })
        if (emailID.length) {
            return res.status(400).json({ errorMessage: `email ID ${emailID} is already exist!` })
        } else {
            const { userName, email, phoneNumber, profileImage, password } = req.body;

            const saveUser = new userModal({
                userName: userName,
                email: email,
                phoneNumber: phoneNumber,
                profileImage: profileImage,
                password: password
            });
            const result = await saveUser.save();
            console.log(result);
            return res.json({Message:"User Created Successfully",
            data:result});
        }
    } catch (error) {
        console.log(error);
        res.send('Someting went wrong');
    }
}

export default async function updateUser(req, res) {
    try {
        const emailID = req.params.email;
        const result = await userModal.findOneAndUpdate(emailID, req.body);
        console.log(result);
        return res.json({Message:"User updated successfully",
        data:result});
    } catch (error) {
        console.log(error);
        res.send('Something went wrong');
    }
}
